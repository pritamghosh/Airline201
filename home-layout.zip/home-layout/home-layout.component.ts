import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Globals } from '../shared/global';
import { AuthService } from '../authentication/auth.service';
import { BackEndAPI } from '../shared/backend.api';
@Component({
  selector: 'app-home-layout',
  templateUrl: './home-layout.component.html',
  styleUrls: ['./home-layout.component.css']
})
export class HomeLayoutComponent implements OnInit {

  isAuthenticated: boolean = false;
  logOutFlag = false;
  username : string;
  userRole : string;

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit() {

    // display login username
    this.username = this.authService.getLoggedInUsername();
    this.authService.usernameSubject.subscribe(username => {
        this.username = username;
    });
    
    //display login user role
    this.userRole = this.authService.getUserRole();
    this.authService.userRole.subscribe(userRole => {

      if(userRole == 'ROLE_ADMIN_WRITE')
        this.userRole = "ADMIN";
      else
        this.userRole= "USER";
    });

  }

  instanceMngCall(){

    this.router.navigate(["/admin/instanceManagment"]);
  
  }

  userMngCall(){

    this.router.navigate(["/admin/newUserManagement"]);
  
  }
  
  notificationMngCall(){
    this.router.navigate(["/admin/notificationManagement"]);
  
  }
  
  ldapMngCall(){
    this.router.navigate(["/admin/ldapConfigManagement"]);
  
  }
  dashboardCall(){

  this.router.navigate(["/dashboard"]);

}

templateMngCall(){
   this.router.navigate(["/admin/template-management"]);
}

settingsMngCall(){
  this.router.navigate(["/admin/settings-management"]);

}

logout(){   
  let xhr = new XMLHttpRequest(); 
  xhr.open("GET", BackEndAPI.LOCAL_TESTING_URL + "logout", true);
  xhr.setRequestHeader("Content-Type", "application/json"); 
  this.isAuthenticated = false;   
  //this.displayHeaderAndUserTab = false;  
  this.logOutFlag = true;
  localStorage.setItem("logOutFlag", "true");
  this.router.navigate(["/login"]);
  localStorage.clear();
  sessionStorage.clear();
}

}
